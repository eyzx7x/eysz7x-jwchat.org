from django.apps import AppConfig


class XmppAccountsConfig(AppConfig):
    name = 'xmpp_accounts'
